-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: j9a604.p.ssafy.io    Database: S09P22A604
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `capsule`
--

DROP TABLE IF EXISTS `capsule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `capsule` (
  `capsule_id` int NOT NULL AUTO_INCREMENT,
  `url` varchar(255) DEFAULT NULL,
  `year` int DEFAULT NULL,
  `user_id` binary(16) DEFAULT NULL,
  PRIMARY KEY (`capsule_id`),
  KEY `FKt85mtc8n3hmv8nqew1eqffse4` (`user_id`),
  CONSTRAINT `FKt85mtc8n3hmv8nqew1eqffse4` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `capsule`
--

LOCK TABLES `capsule` WRITE;
/*!40000 ALTER TABLE `capsule` DISABLE KEYS */;
INSERT INTO `capsule` VALUES (2,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/640e6380-dab4-437d-9abd-d669e1746a97.png',2023,_binary '�\�\�\n��G\�!\�I�;�'),(4,NULL,2023,_binary '\�hɦe#I�� �,x�\'�'),(7,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/40bee13c-083b-4774-8a49-c140634a69ea.jpeg',2023,_binary '\�lv\�C���ܽOH\'\�'),(8,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/03e4c59f-ac0a-4f3d-b2d1-f462ad93d79c.jpeg',2023,_binary '��UO�H<�9R�'),(9,NULL,2023,_binary '�+/�{\"M��\�\\�\�r\0'),(10,NULL,2023,_binary '9W\�M�[G���\�4w '),(11,NULL,2023,_binary '\�hɦe#I�� �,x�\'�'),(13,NULL,2023,_binary '�s�vzE��4�i�\�\�_'),(14,NULL,2023,_binary '1�V\�g�Oϟ[�`\�nK\�'),(15,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/498baa26-e8d5-4ec0-8e7a-ab7bc507aff7.jpeg',2023,_binary '�3\�R0M\n�\�O��ʲ'),(17,NULL,2023,_binary 'gh�9�)Ct�ޱ�~K��'),(18,NULL,2023,_binary '\�\�/^_A���QwF��\�'),(19,NULL,2023,_binary '`\�MגMG�\�\�|\'y0'),(21,NULL,2023,_binary 'K\�E\�7I\��[�\�\'\�'),(23,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/ad2eb7b5-6867-4b6f-8fc9-7b7ba1446b73.jpeg',2023,_binary '�}\�΢xOÄ�!R��I�'),(24,NULL,2023,_binary ':\�z\�5N��ZR\��'),(25,NULL,2023,_binary '<�G���\�²��'),(26,NULL,2023,_binary '\\��\�0NϨ\�\r0ds�'),(27,NULL,2023,_binary '.��MBW��\�x\�ru'),(28,NULL,2023,_binary 'y����\�E��e\�e\�j٪'),(29,NULL,2023,_binary 'ϒm�\�\�Cޭrr\�K\ri\n'),(30,NULL,2023,_binary '�/�\�\�F��J���T'),(31,NULL,2023,_binary 'I�\�w/Jg��,M/s('),(32,NULL,2023,_binary '�?��VHM��\�y�˨'),(33,NULL,2023,_binary '4��G\0�X$�\�j�'),(34,NULL,2023,_binary 'v&\�RZ^Bu��il\�\�\�'),(35,NULL,2023,_binary 'QO�ʍ�HЇϮ��f��'),(36,NULL,2023,_binary '�$Ʈ\�\�F4�Ч�L��\�'),(37,NULL,2023,_binary '\�ɥc��Kꅆ��\�`B\�'),(38,NULL,2023,_binary '����\�tE\'�v۝\Z`\�p');
/*!40000 ALTER TABLE `capsule` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-06 11:32:30
