-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: j9a604.p.ssafy.io    Database: S09P22A604
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `children`
--

DROP TABLE IF EXISTS `children`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `children` (
  `children_id` bigint NOT NULL AUTO_INCREMENT,
  `birthday` date DEFAULT NULL,
  `children_image` varchar(255) DEFAULT NULL,
  `gender` int DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `user_id` binary(16) DEFAULT NULL,
  PRIMARY KEY (`children_id`),
  KEY `FK8xveadpbqq86cakn73swelcvy` (`user_id`),
  CONSTRAINT `FK8xveadpbqq86cakn73swelcvy` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `children`
--

LOCK TABLES `children` WRITE;
/*!40000 ALTER TABLE `children` DISABLE KEYS */;
INSERT INTO `children` VALUES (1,'2023-09-03',NULL,1,'mungmung',_binary 'I\�$\0��A��t���\�j'),(2,'2023-10-13',NULL,0,'yaong',_binary 'I\�$\0��A��t���\�j'),(3,'2023-09-13',NULL,0,'yaong123',_binary '��UO�H<�9R�'),(6,'2023-09-01',NULL,1,'고양이',_binary '��UO�H<�9R�'),(7,'2023-09-24',NULL,0,'강아지22',_binary '��UO�H<�9R�'),(8,'2012-09-12','https://youkids.s3.ap-northeast-2.amazonaws.com/image/88c5849f-8a77-4b08-bf2c-8e096afbbe54.jpeg',1,'호랑이3',_binary '��UO�H<�9R�'),(9,'2023-09-15',NULL,1,'으르렁',_binary '��UO�H<�9R�'),(10,'1994-08-26','https://youkids.s3.ap-northeast-2.amazonaws.com/image/4a530d66-fc5b-4afc-aa41-5e7be84b38d0.jpeg',1,'정성찬123',_binary '��UO�H<�9R�'),(11,'2023-09-15',NULL,1,'흐으음',_binary '�\�\�\n��G\�!\�I�;�'),(12,'2015-09-10',NULL,0,'사자',_binary '��UO�H<�9R�'),(13,'2022-02-01','https://youkids.s3.ap-northeast-2.amazonaws.com/image/c1d3f954-a735-470e-ab2d-c4e170f8a82b.jpeg',0,'푸바오',_binary '��UO�H<�9R�'),(14,'2022-02-01','https://youkids.s3.ap-northeast-2.amazonaws.com/image/7fe3ec41-938b-4eae-95fa-79b5891b8f82.jpeg',1,'푸바오',_binary '��UO�H<�9R�'),(15,'2022-02-01','https://youkids.s3.ap-northeast-2.amazonaws.com/image/e9b401c3-b5d8-4701-bbdd-9560372ae1df.jpeg',0,'오징',_binary '��UO�H<�9R�'),(16,'2022-02-01','https://youkids.s3.ap-northeast-2.amazonaws.com/image/9b971bf9-3e51-4ab1-8612-99b9a17ca660.jpeg',0,'강영현',_binary '��UO�H<�9R�'),(17,'2023-09-27','https://youkids.s3.ap-northeast-2.amazonaws.com/image/febd2e0f-cc1c-4064-9ba6-8c4b2cccd04b.jpeg',0,'문태일',_binary '��UO�H<�9R�'),(18,'2023-09-27','https://youkids.s3.ap-northeast-2.amazonaws.com/image/8e51f970-92fb-4dd9-9407-77eb47038135.jpeg',0,'이태용',_binary '��UO�H<�9R�'),(19,'2023-09-04','https://youkids.s3.ap-northeast-2.amazonaws.com/image/7ecb4731-8a67-4742-9feb-7d74fd28b218.jpeg',1,'애옹',_binary '��UO�H<�9R�'),(20,'1994-08-26','https://youkids.s3.ap-northeast-2.amazonaws.com/image/399b5381-f2e9-4429-8ee4-041ed85ae941.jpeg',0,'정성찬',_binary '��UO�H<�9R�'),(21,'2023-10-01','https://youkids.s3.ap-northeast-2.amazonaws.com/image/8fbd1de7-94a7-4bf8-a3df-aa59ed545072.jpeg',0,'앤톤',_binary '�+/�{\"M��\�\\�\�r\0'),(22,'2023-10-01','https://youkids.s3.ap-northeast-2.amazonaws.com/image/3567076a-93dd-4f67-891a-ecf4de85d145.jpeg',0,'앤톤',_binary '�+/�{\"M��\�\\�\�r\0'),(23,'2023-10-01','https://youkids.s3.ap-northeast-2.amazonaws.com/image/70de2df3-e934-4f98-85c6-d367dae1ae01.jpeg',0,'앤톤',_binary '�+/�{\"M��\�\\�\�r\0'),(24,'2023-10-01','https://youkids.s3.ap-northeast-2.amazonaws.com/image/12c944a4-e10e-49b4-890e-b2956a3713dd.jpeg',1,'앤톤',_binary '��UO�H<�9R�'),(25,'1988-10-21','https://youkids.s3.ap-northeast-2.amazonaws.com/image/e8142cdb-f870-4841-8583-0b2bbcb370fe.jpeg',0,'황민현',_binary '��UO�H<�9R�'),(27,'1973-10-26','https://youkids.s3.ap-northeast-2.amazonaws.com/image/77d19344-c810-4dc4-bfc9-560ff11a175e.jpeg',1,'푸른 눈의 고양이',_binary '��UO�H<�9R�'),(28,'2023-10-03','https://youkids.s3.ap-northeast-2.amazonaws.com/image/7fb9837a-2ce0-45f4-8efd-bb41760ccdbd.jpeg',0,'코코',_binary '�3\�R0M\n�\�O��ʲ'),(29,'2023-10-05','https://youkids.s3.ap-northeast-2.amazonaws.com/image/12e65966-2007-408a-a81b-fb50b691a73c.jpeg',0,'꼬부기',_binary '��UO�H<�9R�'),(30,'2019-10-17','https://youkids.s3.ap-northeast-2.amazonaws.com/image/63f16334-bc0a-414e-b390-769859e9045f.png',0,'쵸비',_binary '��UO�H<�9R�'),(31,'2019-10-17','https://youkids.s3.ap-northeast-2.amazonaws.com/image/774672ce-9aa5-4574-bc6f-11e59d1bc769.png',0,'쵸비',_binary '��UO�H<�9R�'),(32,'2019-10-17','https://youkids.s3.ap-northeast-2.amazonaws.com/image/e7780507-eb84-4188-bd09-f90b05c07ab3.png',0,'쵸비',_binary '��UO�H<�9R�'),(33,'2019-10-17','https://youkids.s3.ap-northeast-2.amazonaws.com/image/bccaf22a-9969-42a9-a3fa-e8deb00c91d5.png',0,'쵸비',_binary '��UO�H<�9R�'),(34,'2019-10-17','https://youkids.s3.ap-northeast-2.amazonaws.com/image/2835d8a7-8e99-4045-a0fd-0909feaf7dec.png',0,'쵸비',_binary '��UO�H<�9R�'),(35,'2019-10-17','https://youkids.s3.ap-northeast-2.amazonaws.com/image/eb145064-4f2b-4393-b6ad-36518fc0568f.png',0,'쵸비',_binary '��UO�H<�9R�'),(36,'2019-10-17','https://youkids.s3.ap-northeast-2.amazonaws.com/image/130535d0-6588-49cb-8e6c-0e5abc82e2f5.png',0,'쵸비',_binary '��UO�H<�9R�'),(37,'2019-10-17','https://youkids.s3.ap-northeast-2.amazonaws.com/image/c8bfd28d-2447-4c71-a702-6c362750e456.png',0,'쵸비',_binary '��UO�H<�9R�'),(38,'2019-10-17','https://youkids.s3.ap-northeast-2.amazonaws.com/image/65a538a2-db62-43f1-8847-0206bd724299.png',0,'쵸비',_binary '��UO�H<�9R�'),(39,'2019-10-17','https://youkids.s3.ap-northeast-2.amazonaws.com/image/5e3fa7aa-f084-4e6e-941c-bc4c3639d17e.png',0,'쵸비',_binary '��UO�H<�9R�'),(40,'2019-10-17','https://youkids.s3.ap-northeast-2.amazonaws.com/image/472e82f1-f7e1-4f35-8323-a04dc602a573.png',0,'쵸비',_binary '��UO�H<�9R�'),(41,'2019-10-17','https://youkids.s3.ap-northeast-2.amazonaws.com/image/381b33e8-c02d-4fec-aa93-a229afa661be.png',0,'쵸비',_binary '��UO�H<�9R�'),(42,'2019-10-17','https://youkids.s3.ap-northeast-2.amazonaws.com/image/b1f77195-00b8-4660-9680-074456e0b989.png',0,'쵸비',_binary '��UO�H<�9R�'),(43,'2019-10-17','https://youkids.s3.ap-northeast-2.amazonaws.com/image/eaa66ae4-5812-40f4-93b6-459f773ec1ef.png',0,'쵸비',_binary '��UO�H<�9R�'),(44,'2019-10-17','https://youkids.s3.ap-northeast-2.amazonaws.com/image/977c3d4f-bd23-4d59-a0fb-8a52416ab310.png',0,'쵸비',_binary '��UO�H<�9R�'),(45,'2011-10-28','https://youkids.s3.ap-northeast-2.amazonaws.com/image/ef7e569d-b7d3-4ba4-90d6-2fe3bbbadca1.jpeg',0,'하품하는 고양이',_binary '��UO�H<�9R�'),(46,'1995-10-25','https://youkids.s3.ap-northeast-2.amazonaws.com/image/4b263dc6-bbd1-4995-a347-e5d68e77118c.jpeg',0,'우리 아들',_binary '��UO�H<�9R�'),(47,'1903-10-22','https://youkids.s3.ap-northeast-2.amazonaws.com/image/87df5168-262b-4e56-9c45-91ec07bb6da2.jpeg',1,'한강',_binary '��UO�H<�9R�'),(48,'2023-09-13','https://youkids.s3.ap-northeast-2.amazonaws.com/image/ec5ba6fa-76d7-4a6b-899e-e2e2e10623eb.jpeg',1,'꼬질이',_binary '��UO�H<�9R�'),(49,'2023-10-05',NULL,0,'ㅇㅇ',_binary '�}\�΢xOÄ�!R��I�'),(50,'2023-10-05','https://youkids.s3.ap-northeast-2.amazonaws.com/image/192a7ced-90d4-483e-a0cd-8f8633a85877.jpeg',0,'ㅇㅇㅇ',_binary '�}\�΢xOÄ�!R��I�');
/*!40000 ALTER TABLE `children` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-06 11:32:26
