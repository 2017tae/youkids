-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: j9a604.p.ssafy.io    Database: S09P22A604
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `memory_image`
--

DROP TABLE IF EXISTS `memory_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `memory_image` (
  `memory_image_id` bigint NOT NULL AUTO_INCREMENT,
  `memory_url` varchar(255) DEFAULT NULL,
  `memory_id` bigint DEFAULT NULL,
  PRIMARY KEY (`memory_image_id`),
  KEY `FKdm4x79i6g8p4k7wbdlosy3s24` (`memory_id`),
  CONSTRAINT `FKdm4x79i6g8p4k7wbdlosy3s24` FOREIGN KEY (`memory_id`) REFERENCES `memory` (`memory_id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `memory_image`
--

LOCK TABLES `memory_image` WRITE;
/*!40000 ALTER TABLE `memory_image` DISABLE KEYS */;
INSERT INTO `memory_image` VALUES (11,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/640e6380-dab4-437d-9abd-d669e1746a97.png',14),(19,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/427f6cbc-aaf0-4f88-b63d-faa9d0143716.jpeg',22),(20,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/aeebeeb0-5f82-468f-8ecf-0053e003f607.webp',22),(22,'https://youkids.s3.ap-northeast-2.amazonaws.com/multipart/43e30199-239b-4ea1-9fee-9b844d9afba5.form-data',23),(23,'https://youkids.s3.ap-northeast-2.amazonaws.com/multipart/68aad13f-2d18-40a2-8286-10ed671e7ec3.form-data',24),(24,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/e6df8330-bc1e-4701-9355-345c05bdc357.png',28),(25,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/d8bfd79c-aed6-42db-84d0-4814970d97ab.png',29),(26,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/7e4bb3a9-fdf9-4c03-b305-2cfee92f9713.jpeg',30),(27,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/f0580c00-eb0f-4ca4-b173-b03693ed5b8b.jpeg',31),(28,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/bf792af2-d2a3-4fcb-b281-41c09ec0cb1b.jpeg',32),(29,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/cd69bbfb-7be2-443f-ba2c-e35bf38cbd32.jpeg',33),(30,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/36f5eaa1-1cd8-4f71-a696-f586bf0f6736.jpeg',34),(31,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/6e91c371-0ac9-43a0-8150-2179b75dd075.jpeg',35),(32,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/16f25b2f-49c4-4428-aca0-7a5ea00d7719.jpeg',36),(33,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/62ce0723-6e9e-498c-90da-42893d8fe9dd.jpeg',37),(34,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/1217a45c-4568-4c1b-adc4-35fceb152941.jpeg',38),(35,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/a90b2b8a-6cbd-43cd-8109-0e5f26e1c323.png',39),(36,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/e5f109a1-6b8a-4464-b5a3-ffbb86541ccc.png',39),(37,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/b84b47fd-b53a-4e93-bbb0-6d5b3f2a6efe.jpeg',43),(38,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/548e9378-be06-496e-ac67-6d64ec5ed4bc.jpeg',44),(39,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/578cf01c-8165-421d-9186-ad50acf30f5e.jpeg',45),(40,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/8cb11791-d81e-4837-a098-f142777e40e7.jpeg',46),(41,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/ee2689d7-91d8-490a-a5b7-d9eedb5b7024.jpeg',47),(42,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/7e3ee835-3969-44bc-b00b-cd579ddb4979.jpeg',47),(43,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/03e4c59f-ac0a-4f3d-b2d1-f462ad93d79c.jpeg',48),(44,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/ea54cdcb-5ce8-4ec9-9135-37581f815e5c.jpeg',49),(45,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/4f4c611d-bdcb-44b0-b49c-683a9837b309.jpeg',49),(46,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/8dcbc052-ecf4-4e68-8a9c-1d3ec3b36b01.jpeg',49),(47,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/39aa1caf-795a-40aa-8df4-7e4ba6334555.jpeg',49),(48,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/540c8761-c587-4e35-8dd5-26c594d7b842.jpeg',50),(49,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/9090ec1c-3e30-48c6-8cb3-b5f4557470fe.jpeg',50),(50,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/478ce275-0884-4697-9456-f3f215201347.jpeg',50),(51,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/6901d972-a3c6-4175-bf5e-c453a84bc24f.jpeg',50),(52,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/198e5d62-aa38-434b-8e7a-01c371574907.jpeg',51),(53,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/498baa26-e8d5-4ec0-8e7a-ab7bc507aff7.jpeg',52),(54,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/c5259bc4-0d54-4dc2-89e4-2328a8f4e10d.jpeg',53),(55,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/0dafd4d1-3e53-4139-9d7d-ccbf994b15fd.jpeg',53),(56,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/d34fd2f1-7c0a-4129-b5bb-4dbb379b6582.jpeg',53),(57,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/b9627fe9-f69e-4ed5-bfb4-4e8af3029dd8.jpeg',53),(58,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/791d4b93-9f32-4ab5-a846-1bd2ffe8a7e8.jpeg',53),(59,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/63704f25-e6a2-481d-90e4-d51d08b488a2.jpeg',53),(60,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/0412845d-74ae-4fa3-8f6f-101b0ee5dcd7.jpeg',53),(61,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/57fdf59c-f812-4a38-9062-766fd0b560e3.jpeg',53),(62,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/e42d86c1-e0cd-4813-98b0-19111d21b367.jpeg',53),(63,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/07e63a26-c1f7-488e-8f66-85dbd9074e90.png',54),(64,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/95eaa9bd-00dc-4fca-b8f4-0dd069cc6a62.png',55),(65,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/14957889-7c4f-48f5-8c4d-d5987daf5583.png',56),(66,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/0389ab1f-1a72-4c43-a9af-a7bf9cad1cb5.png',57),(67,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/37e5e82b-ca87-484c-9a21-0d3fdb3e2099.png',58),(68,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/c82b6e31-a415-4b67-9259-dcb36c7d1a96.png',59),(69,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/fee87839-8799-4da9-b239-3d4ac53f6dcb.png',59),(70,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/5a37aeae-b452-4021-ac69-5fc93bfd219c.jpeg',60),(71,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/cfac57be-a8ff-48fa-98f1-ee37d2923c80.jpeg',61),(72,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/11098e7e-ae6d-4d2b-81b7-5e813b3f2e7d.jpeg',62),(73,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/d8301e79-2e4a-4567-811c-346bea013f46.jpeg',63),(74,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/d4f0a0e5-bc93-439d-ba40-c17924f9ef67.jpeg',63),(75,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/7dc96adb-d607-4ee3-baa7-0d5ac57bbe26.jpeg',63),(76,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/99fbe42d-5f6a-4d94-ad73-6afdd1f17b91.jpeg',63),(77,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/c34421da-8380-405f-b2c8-2040b3e27faa.jpeg',63),(78,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/4c2e9ec7-da6c-403f-a872-b2f8d57ffadd.jpeg',64),(79,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/13b792a1-ff82-4dd8-9905-5156dd97ed5b.jpeg',64),(80,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/00a954b5-b13d-4073-8045-e985e0deb274.jpeg',65),(81,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/6de1d4cd-d652-4806-964e-71c73006ed30.jpeg',65),(82,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/0791bb82-3762-4092-bbb0-f80970244867.jpeg',65),(83,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/baaa0a44-69ed-4a22-b2c4-a990188c6329.jpeg',65),(84,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/460d89cb-1788-48c6-a77b-4ef8b2c701f7.jpeg',65),(85,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/ae026b8f-d399-4ff8-bf45-eaad779fd99c.jpeg',65),(86,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/d500459c-e00b-4ced-bdbd-7a2ebe898871.jpeg',66),(87,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/ad2eb7b5-6867-4b6f-8fc9-7b7ba1446b73.jpeg',67),(88,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/40bee13c-083b-4774-8a49-c140634a69ea.jpeg',68),(89,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/93f5ff9e-4f11-4716-b230-81da030f9dfa.jpeg',69),(90,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/fa6b60ab-7e7e-4e01-9ab6-c95f8544e8c0.jpeg',69),(91,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/f7675f27-654d-424e-ba93-05d2fa48bb2b.jpeg',69),(92,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/39bf26cc-d5a0-4b41-a2de-ed0c07ef459c.jpeg',69),(93,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/ccb6eadc-494c-461e-b188-8337afd52dd4.jpeg',69),(94,'https://youkids.s3.ap-northeast-2.amazonaws.com/image/23322e1e-1a19-4570-b426-768e02762f82.jpeg',69);
/*!40000 ALTER TABLE `memory_image` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-06 11:32:29
