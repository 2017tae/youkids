-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: j9a604.p.ssafy.io    Database: S09P22A604
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `top_review_place`
--

DROP TABLE IF EXISTS `top_review_place`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `top_review_place` (
  `place_id` int NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `category` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `naver_review_num` int DEFAULT NULL,
  `visited_review_num` int DEFAULT NULL,
  PRIMARY KEY (`place_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `top_review_place`
--

LOCK TABLES `top_review_place` WRITE;
/*!40000 ALTER TABLE `top_review_place` DISABLE KEYS */;
INSERT INTO `top_review_place` VALUES (1,'제주 제주시 조천읍 번영로 1278-169','테마파크','https://picturepractice.s3.ap-northeast-2.amazonaws.com/Park/19584967%231.png','에코랜드 테마파크',27225,5),(4,'전남 여수시 소라면 안심산길 155','테마파크','https://picturepractice.s3.ap-northeast-2.amazonaws.com/Park/1615094405%231.png','여수 유월드 루지 테마파크',21265,4),(15,'경기 부천시 조마루로 2','테마파크','https://picturepractice.s3.ap-northeast-2.amazonaws.com/Park/13294864%231.png','웅진플레이도시',20736,1),(93,'경기 용인시 처인구 포곡읍 에버랜드로 199','테마파크','https://picturepractice.s3.ap-northeast-2.amazonaws.com/Park/11574457%231.png','에버랜드',61021,1),(95,'서울 송파구 올림픽로 240','테마파크','https://picturepractice.s3.ap-northeast-2.amazonaws.com/Park/11583235%231.png','롯데월드 어드벤처',45475,1),(99,'경기 용인시 기흥구 민속촌로 90 한국민속촌','테마파크','https://picturepractice.s3.ap-northeast-2.amazonaws.com/Park/11620801%231.png','한국민속촌',22436,1),(103,'경기 안성시 공도읍 대신두길 28','테마파크','https://picturepractice.s3.ap-northeast-2.amazonaws.com/Park/20770831%231.png','농협경제지주 안성팜랜드',40797,1),(105,'제주 서귀포시 성산읍 섭지코지로 95 아쿠아플라넷 제주','테마파크','https://picturepractice.s3.ap-northeast-2.amazonaws.com/Park/19708047%231.png','아쿠아플라넷 제주',44956,5),(108,'대구 달서구 두류공원로 200 이월드','테마파크','https://picturepractice.s3.ap-northeast-2.amazonaws.com/Park/11556649%231.png','이월드',41702,3),(117,'강원 춘천시 남산면 햇골길 80','테마파크','https://picturepractice.s3.ap-northeast-2.amazonaws.com/Park/19928010%231.png','제이드가든',23679,2),(501,'서울 강서구 양천로 431 홈플러스가양점 지하1층 X11, YC호','키즈카페','https://picturepractice.s3.ap-northeast-2.amazonaws.com/kidscafe/1745581612%231.png','몬스터파크 가양점',6468,1),(506,'경기 안양시 동안구 관악대로 272 키즈맘센터 오렌지동 지하1층','키즈카페','https://picturepractice.s3.ap-northeast-2.amazonaws.com/kidscafe/1431855309%231.png','애플트리 로라바운스',8735,1),(635,'경기 용인시 기흥구 구성로 357 용인테크노밸리 D동 1층','키즈카페','https://picturepractice.s3.ap-northeast-2.amazonaws.com/kidscafe/1618604471%231.png','너티차일드 용인점',5061,1),(740,'경기 안산시 단원구 광덕1로 276 6층 자이언트제트','키즈카페','https://picturepractice.s3.ap-northeast-2.amazonaws.com/kidscafe/1080053133%231.png','자이언트제트',5132,1),(839,'인천 서구 청라에메랄드로 79 커낼에비뉴 지하 1층','키즈카페','https://picturepractice.s3.ap-northeast-2.amazonaws.com/kidscafe/1251102754%231.png','너티차일드 청라점',5653,1),(841,'인천 서구 염곡로 351 롯데슈퍼 신현점 1층','키즈카페','https://picturepractice.s3.ap-northeast-2.amazonaws.com/kidscafe/1785935585%231.png','월드킹 인천점',5203,1),(998,'경기 고양시 일산동구 강송로 33 벨라시타 본동2층','키즈카페','https://picturepractice.s3.ap-northeast-2.amazonaws.com/kidscafe/1667084568%231.png','물노리베이비 일산벨라시타점',6411,1),(1417,'부산 해운대구 APEC로 30','키즈카페','https://picturepractice.s3.ap-northeast-2.amazonaws.com/kidscafe/1801736280%231.png','벡스코 상상체험 키즈월드',6969,3),(1420,'부산 강서구 명지국제1로 60-1 7층, 8층','키즈카페','https://picturepractice.s3.ap-northeast-2.amazonaws.com/kidscafe/1218456344%231.png','몬스터파크',7432,3),(1422,'부산 강서구 명지국제8로10번길 51 시엘주차타워 3층~6층','키즈카페','https://picturepractice.s3.ap-northeast-2.amazonaws.com/kidscafe/1207877340%231.png','히어로플레이파크 부산명지점',7623,3),(1627,'제주 서귀포시 안덕면 신화역사로 15 오설록','박물관','https://picturepractice.s3.ap-northeast-2.amazonaws.com/museum/11612628%231.png','오설록 티 뮤지엄',35163,5),(1630,'제주 서귀포시 안덕면 산록남로762번길 69 본태박물관','박물관','https://picturepractice.s3.ap-northeast-2.amazonaws.com/museum/31346905%231.png','본태박물관',8778,5),(1633,'제주 제주시 1100로 3198-8 넥슨컴퓨터박물관','박물관','https://picturepractice.s3.ap-northeast-2.amazonaws.com/museum/33907116%231.png','넥슨컴퓨터박물관',7682,5),(1635,'제주 서귀포시 안덕면 한창로 243','박물관','https://picturepractice.s3.ap-northeast-2.amazonaws.com/museum/1369820318%231.png','피규어뮤지엄제주',11873,5),(1636,'제주 제주시 1100로 2894-72 제주러브랜드','박물관','https://picturepractice.s3.ap-northeast-2.amazonaws.com/museum/11607761%231.png','제주러브랜드',5072,5),(1660,'전북 전주시 완산구 동문길 33-20','박물관','https://picturepractice.s3.ap-northeast-2.amazonaws.com/museum/1813940329%231.png','전주난장',7513,4),(1706,'경북 경주시 보불로 216-8','박물관','https://picturepractice.s3.ap-northeast-2.amazonaws.com/museum/32133956%231.png','추억의달동네',11096,3),(1738,'경북 문경시 가은읍 왕능길 114','박물관','https://picturepractice.s3.ap-northeast-2.amazonaws.com/museum/11783969%231.png','문경 에코월드',6068,3),(1767,'강원 춘천시 서면 박사로 854 애니메이션박물관','박물관','https://picturepractice.s3.ap-northeast-2.amazonaws.com/museum/11620653%231.png','애니메이션박물관',6659,2),(1784,'충남 천안시 동남구 목천읍 독립기념관로 1 독립기념관','박물관','https://picturepractice.s3.ap-northeast-2.amazonaws.com/museum/11620331%231.png','독립기념관',6599,2);
/*!40000 ALTER TABLE `top_review_place` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-10-06 11:32:31
